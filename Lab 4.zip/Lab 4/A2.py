import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Read the Excel file
# Make sure to save your Excel file as 'lab_data.xlsx' in the same folder as this script
df = pd.read_excel('lab_data.xlsx')

# Display the data
print("Dataset:")
print(df)
print("\n")

# Prepare features (X) and target (y)
# Assuming we're predicting Payment (Rs) based on Candies, Mangoes, and Milk Packets
X = df[['Candies (#)', 'Mangoes (Kg)', 'Milk Packets (#)']]
y = df['Payment (Rs)']

# Split data into training and testing sets (80-20 split)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train the model
model = LinearRegression()
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Calculate metrics
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

# Calculate MAPE manually
mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100

# Display results
print("=" * 60)
print("MODEL PERFORMANCE METRICS")
print("=" * 60)
print(f"Mean Squared Error (MSE):       {mse:.2f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.2f}")
print(f"Mean Absolute Percentage Error (MAPE): {mape:.2f}%")
print(f"R² Score:                       {r2:.4f}")
print("=" * 60)

# Display predictions vs actual
print("\nPredictions vs Actual Values:")
print("-" * 40)
comparison = pd.DataFrame({
    'Actual': y_test.values,
    'Predicted': y_pred,
    'Error': y_test.values - y_pred
})
print(comparison)

# Display model coefficients
print("\n" + "=" * 60)
print("MODEL COEFFICIENTS")
print("=" * 60)
print(f"Intercept: {model.intercept_:.2f}")
for feature, coef in zip(X.columns, model.coef_):
    print(f"{feature}: {coef:.2f}")
print("=" * 60)

# Analysis
print("\n" + "=" * 60)
print("ANALYSIS")
print("=" * 60)
print(f"1. R² Score of {r2:.4f} means the model explains {r2*100:.2f}% of variance")
print(f"2. RMSE of {rmse:.2f} Rs indicates average prediction error")
print(f"3. MAPE of {mape:.2f}% shows average percentage deviation")

if r2 > 0.8:
    print("4. Model shows STRONG predictive performance")
elif r2 > 0.6:
    print("4. Model shows GOOD predictive performance")
elif r2 > 0.4:
    print("4. Model shows MODERATE predictive performance")
else:
    print("4. Model shows WEAK predictive performance")
print("=" * 60)