import numpy as np
import pandas as pd
from PIL import Image
import os
from scipy import ndimage

print("="*70)
print("A6: Galaxy Feature Extraction - Save to Excel")
print("="*70)

# Configuration - Using only 2 classes
CLASSES = ['elliptical', 'spiral']  # Only 2 classes as required
CLASS_LABELS = {'elliptical': 0, 'spiral': 1}
IMG_SIZE = 128
DATA_DIR = '../galaxy_dataset'  # Path to galaxy images

# Function to extract 2 features from an image
def extract_features(img_array):
    """
    Extract 2 features from galaxy image:
    Feature 1: Average brightness (mean pixel intensity)
    Feature 2: Edge density (measure of structure/detail)
    """
    # Convert to grayscale if RGB
    if len(img_array.shape) == 3:
        gray = np.mean(img_array, axis=2)
    else:
        gray = img_array
    
    # Feature 1: Average brightness
    brightness = np.mean(gray)
    
    # Feature 2: Edge density using Sobel filter
    edges_x = ndimage.sobel(gray, axis=0)
    edges_y = ndimage.sobel(gray, axis=1)
    edges = np.hypot(edges_x, edges_y)
    edge_density = np.mean(edges)
    
    return brightness, edge_density

# Load galaxy images and extract features
print("\nProcessing galaxy images...")
print("-"*70)

data_rows = []

for class_name in CLASSES:
    class_path = os.path.join(DATA_DIR, class_name)
    class_label = CLASS_LABELS[class_name]
    
    if not os.path.exists(class_path):
        print(f"Warning: {class_path} not found!")
        continue
    
    print(f"\nProcessing {class_name} galaxies...")
    count = 0
    
    for img_name in os.listdir(class_path):
        if img_name.lower().endswith(('.png', '.jpg', '.jpeg')):
            img_path = os.path.join(class_path, img_name)
            try:
                # Load image
                img = Image.open(img_path).convert('RGB')
                img = img.resize((IMG_SIZE, IMG_SIZE))
                img_array = np.array(img) / 255.0
                
                # Extract 2 features
                brightness, edge_density = extract_features(img_array)
                
                # Store data
                data_rows.append({
                    'Image_Name': img_name,
                    'Galaxy_Type': class_name,
                    'Class_Label': class_label,
                    'Feature1_Brightness': brightness,
                    'Feature2_EdgeDensity': edge_density
                })
                
                count += 1
                print(f"  ✓ {img_name}: Brightness={brightness:.4f}, EdgeDensity={edge_density:.4f}")
                
            except Exception as e:
                print(f"  ✗ Error loading {img_path}: {e}")
    
    print(f"  Total processed: {count} images")

# Create DataFrame
df = pd.DataFrame(data_rows)

print("\n" + "="*70)
print("Feature Extraction Summary")
print("="*70)
print(f"\nTotal images processed: {len(df)}")
print(f"\nDataFrame Info:")
print(df.info())

print(f"\nFirst 5 rows:")
print(df.head())

print(f"\nFeature Statistics:")
print(df.groupby('Galaxy_Type')[['Feature1_Brightness', 'Feature2_EdgeDensity']].describe())

# Save to Excel
excel_filename = 'galaxy_features.xlsx'
df.to_excel(excel_filename, index=False, sheet_name='Galaxy_Features')

print(f"\n{'='*70}")
print(f"✓ Features saved to '{excel_filename}'")
print(f"{'='*70}")

print("\nExcel file contains:")
print("  - Image_Name: Original image filename")
print("  - Galaxy_Type: elliptical or spiral")
print("  - Class_Label: 0 (elliptical) or 1 (spiral)")
print("  - Feature1_Brightness: Average pixel intensity")
print("  - Feature2_EdgeDensity: Amount of edges/structure")

print("\nYou can now run A6_galaxy_knn_from_excel.py to perform kNN analysis!")