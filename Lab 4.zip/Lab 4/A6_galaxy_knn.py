import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from matplotlib.colors import ListedColormap

print("="*70)
print("A6: Galaxy kNN Classification from Excel (A3-A5 Analysis)")
print("="*70)

# Load data from Excel
excel_filename = 'galaxy_features.xlsx'
print(f"\nLoading data from '{excel_filename}'...")

try:
    df = pd.read_excel(excel_filename)
    print(f"✓ Loaded {len(df)} samples")
except FileNotFoundError:
    print(f"ERROR: '{excel_filename}' not found!")
    print("Please run A6_feature_extraction.py first to generate the Excel file.")
    exit()

print(f"\nDataset Info:")
print(df.head())

# Extract features and labels
X_train = df[['Feature1_Brightness', 'Feature2_EdgeDensity']].values
y_train = df['Class_Label'].values
class_names_map = {0: 'Elliptical', 1: 'Spiral'}

print(f"\nTraining data shape: {X_train.shape}")
print(f"Labels shape: {y_train.shape}")

print(f"\nClass distribution:")
for class_label in [0, 1]:
    count = np.sum(y_train == class_label)
    print(f"  {class_names_map[class_label]} (Class {class_label}): {count} samples")

# ============================================================================
print("\n" + "="*70)
print("A6-A3: Training Data Scatter Plot")
print("="*70)

plt.figure(figsize=(10, 8))
colors = ['blue', 'red']
class_labels = ['Elliptical (Class 0)', 'Spiral (Class 1)']

for class_idx in range(2):
    mask = y_train == class_idx
    plt.scatter(X_train[mask, 0], X_train[mask, 1], 
               c=colors[class_idx], label=class_labels[class_idx],
               s=150, edgecolors='black', linewidths=1.5, alpha=0.7)

plt.xlabel('Feature 1: Brightness', fontsize=12)
plt.ylabel('Feature 2: Edge Density', fontsize=12)
plt.title('A6-A3: Galaxy Training Data Scatter Plot\n(2 Features from Real Galaxy Images)', 
         fontsize=14, fontweight='bold')
plt.legend(fontsize=11)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('A6_A3_galaxy_training_data.png', dpi=300)
plt.close()

print("✓ Saved: A6_A3_galaxy_training_data.png")

# ============================================================================
print("\n" + "="*70)
print("A6-A4: kNN Classification with k=3")
print("="*70)

# Generate test grid
brightness_min, brightness_max = X_train[:, 0].min(), X_train[:, 0].max()
edge_min, edge_max = X_train[:, 1].min(), X_train[:, 1].max()

# Add margin
margin = 0.05
brightness_range = np.arange(brightness_min - margin, brightness_max + margin, 0.005)
edge_range = np.arange(edge_min - margin, edge_max + margin, 0.005)
xx, yy = np.meshgrid(brightness_range, edge_range)

X_test = np.c_[xx.ravel(), yy.ravel()]

print(f"Test grid size: {X_test.shape[0]} points")

# Train kNN with k=3
k = 3
print(f"Training kNN with k={k}...")
knn = KNeighborsClassifier(n_neighbors=k)
knn.fit(X_train, y_train)

# Predict
y_test_pred = knn.predict(X_test)
print("✓ Classification complete")

# Plot
plt.figure(figsize=(12, 10))

cmap_light = ListedColormap(['lightblue', 'lightcoral'])
plt.scatter(X_test[:, 0], X_test[:, 1], c=y_test_pred, 
           cmap=cmap_light, s=10, alpha=0.5, edgecolors='none')

# Overlay training points
for class_idx in range(2):
    mask = y_train == class_idx
    plt.scatter(X_train[mask, 0], X_train[mask, 1], 
               c=colors[class_idx], label=f'Training {class_labels[class_idx]}',
               s=200, edgecolors='black', linewidths=2, marker='o', alpha=0.9, zorder=5)

plt.xlabel('Feature 1: Brightness', fontsize=12)
plt.ylabel('Feature 2: Edge Density', fontsize=12)
plt.title(f'A6-A4: Galaxy Classification with kNN (k={k})\nDecision Boundary', 
         fontsize=14, fontweight='bold')
plt.legend(fontsize=11)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('A6_A4_galaxy_knn_k3.png', dpi=300)
plt.close()

print("✓ Saved: A6_A4_galaxy_knn_k3.png")

# ============================================================================
print("\n" + "="*70)
print("A6-A5: Various k Values - Decision Boundary Changes")
print("="*70)

k_values = [1, 3, 5, 7, 10, 15]

fig, axes = plt.subplots(2, 3, figsize=(18, 12))
axes = axes.ravel()

for idx, k in enumerate(k_values):
    print(f"Processing k={k}...")
    
    # Train kNN
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    
    # Predict
    y_pred = knn.predict(X_test)
    
    # Plot
    ax = axes[idx]
    ax.scatter(X_test[:, 0], X_test[:, 1], c=y_pred, 
              cmap=cmap_light, s=10, alpha=0.5, edgecolors='none')
    
    # Training points
    for class_idx in range(2):
        mask = y_train == class_idx
        ax.scatter(X_train[mask, 0], X_train[mask, 1], 
                  c=colors[class_idx], s=150, edgecolors='black', 
                  linewidths=1.5, marker='o', alpha=0.9, zorder=5)
    
    ax.set_xlabel('Brightness', fontsize=10)
    ax.set_ylabel('Edge Density', fontsize=10)
    ax.set_title(f'k = {k}', fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.3)

plt.suptitle('A6-A5: kNN with Various k Values - Galaxy Classification\n(Elliptical vs Spiral)', 
            fontsize=16, fontweight='bold', y=0.995)
plt.tight_layout()
plt.savefig('A6_A5_galaxy_various_k.png', dpi=300, bbox_inches='tight')
plt.close()

print("✓ Saved: A6_A5_galaxy_various_k.png")

print("\n" + "="*70)
print("ANALYSIS COMPLETE")
print("="*70)
print("\nGenerated files:")
print("  1. A6_A3_galaxy_training_data.png")
print("  2. A6_A4_galaxy_knn_k3.png")
print("  3. A6_A5_galaxy_various_k.png")

print("\n📊 Observations:")
print("  - Features extracted from real galaxy images")
print("  - Elliptical galaxies tend to have lower edge density (smoother)")
print("  - Spiral galaxies have higher edge density (spiral structure)")
print("  - Decision boundaries show how kNN separates the classes")
print("  - As k increases, boundaries become smoother and more generalized")
print("="*70)