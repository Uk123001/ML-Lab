import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from matplotlib.colors import ListedColormap

print("="*70)
print("A5: Repeat for Various k Values - Observe Boundary Changes")
print("="*70)

# Load training data from A3
try:
    X_train = np.load('X_train.npy')
    y_train = np.load('y_train.npy')
    print(f"✓ Loaded training data: {X_train.shape[0]} points")
except FileNotFoundError:
    print("ERROR: Training data not found!")
    print("Please run A3_training_data.py first to generate training data.")
    exit()

# Generate test set (same as A4)
print("\nGenerating test data...")
x_range = np.arange(0, 10.1, 0.1)
y_range = np.arange(0, 10.1, 0.1)
xx, yy = np.meshgrid(x_range, y_range)
X_test = np.c_[xx.ravel(), yy.ravel()]

print(f"Test Data Shape: {X_test.shape}")

# Try different k values
k_values = [1, 3, 5, 7, 10, 15, 20]

print(f"\nTesting k values: {k_values}")
print("="*70)

# Create subplot grid
fig, axes = plt.subplots(2, 4, figsize=(20, 10))
axes = axes.ravel()

colors = ['blue', 'red']
cmap_light = ListedColormap(['lightblue', 'lightcoral'])

for idx, k in enumerate(k_values):
    print(f"\nProcessing k={k}...")
    
    # Train kNN with current k
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    
    # Predict
    y_pred = knn.predict(X_test)
    
    # Calculate prediction distribution
    class0_pct = np.sum(y_pred == 0) / len(y_pred) * 100
    class1_pct = np.sum(y_pred == 1) / len(y_pred) * 100
    print(f"  Class 0: {class0_pct:.1f}% | Class 1: {class1_pct:.1f}%")
    
    # Plot
    ax = axes[idx]
    
    # Background colored by prediction
    ax.scatter(X_test[:, 0], X_test[:, 1], c=y_pred, 
              cmap=cmap_light, s=10, alpha=0.5, edgecolors='none')
    
    # Training points
    for class_idx in range(2):
        mask = y_train == class_idx
        ax.scatter(X_train[mask, 0], X_train[mask, 1], 
                  c=colors[class_idx], s=150, edgecolors='black', 
                  linewidths=1.5, marker='o', alpha=0.9, zorder=5)
    
    ax.set_xlabel('Feature X', fontsize=10)
    ax.set_ylabel('Feature Y', fontsize=10)
    ax.set_title(f'k = {k}', fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.set_xlim(-0.5, 10.5)
    ax.set_ylim(-0.5, 10.5)
    
    print(f"  ✓ Completed k={k}")

# Remove extra subplot
axes[-1].axis('off')

plt.suptitle('A5: kNN Classification with Different k Values\nObserve Decision Boundary Changes', 
            fontsize=16, fontweight='bold', y=1.00)
plt.tight_layout()
plt.savefig('A5_knn_various_k.png', dpi=300, bbox_inches='tight')
plt.show()

print(f"\n✓ Comparison plot saved as 'A5_knn_various_k.png'")

print("\n" + "="*70)
print("DETAILED OBSERVATIONS - Effect of k on Decision Boundaries:")
print("="*70)

print("\n1️⃣ k=1 (Most Complex):")
print("   - Very jagged, irregular boundaries")
print("   - Each test point classified by its single nearest neighbor")
print("   - High sensitivity to individual training points")
print("   - Creates 'islands' around each training point")
print("   - Prone to OVERFITTING - memorizes training data noise")

print("\n2️⃣ k=3 (Low k):")
print("   - Smoother boundaries than k=1")
print("   - Still follows local patterns closely")
print("   - Some jaggedness remains but reduced")
print("   - Good for capturing local structure")

print("\n3️⃣ k=5 (Moderate):")
print("   - Balanced between flexibility and generalization")
print("   - Boundaries are reasonably smooth")
print("   - Less sensitive to individual outliers")
print("   - Often a good default choice")

print("\n4️⃣ k=7-10 (Moderate-High):")
print("   - Noticeably smoother boundaries")
print("   - More generalized classification regions")
print("   - Reduces impact of noisy training points")
print("   - May start missing fine-grained patterns")

print("\n5️⃣ k=15-20 (Very High):")
print("   - Very smooth, simplified boundaries")
print("   - High generalization, low variance")
print("   - Large regions of uniform classification")
print("   - May UNDERFIT if true boundary is complex")
print("   - Less influenced by individual training points")

print("\n" + "="*70)
print("KEY INSIGHTS:")
print("="*70)
print("\n📈 As k INCREASES:")
print("   ↗ Decision boundaries become SMOOTHER")
print("   ↗ Model becomes MORE generalized")
print("   ↗ LESS sensitive to individual data points")
print("   ↗ LESS prone to overfitting")
print("   ↗ MORE prone to underfitting")
print("   ↗ Computational cost increases (more neighbors to check)")

print("\n📉 As k DECREASES:")
print("   ↘ Decision boundaries become MORE COMPLEX/JAGGED")
print("   ↘ Model becomes MORE flexible")
print("   ↘ MORE sensitive to individual data points")
print("   ↘ MORE prone to overfitting")
print("   ↘ LESS prone to underfitting")
print("   ↘ Faster computation (fewer neighbors)")

print("\n🎯 BIAS-VARIANCE TRADEOFF:")
print("   - Low k → Low bias, High variance (overfitting risk)")
print("   - High k → High bias, Low variance (underfitting risk)")
print("   - Optimal k depends on data complexity and noise level")

print("\n💡 PRACTICAL RECOMMENDATION:")
print("   - Start with k=√n (square root of training samples)")
print("   - For this dataset (n=20): k ≈ 4-5 is reasonable")
print("   - Use cross-validation to find optimal k")
print("   - Prefer odd k values to avoid tie votes in binary classification")

print("\n" + "="*70)
