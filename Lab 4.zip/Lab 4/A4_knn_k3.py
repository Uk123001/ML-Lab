import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from matplotlib.colors import ListedColormap

print("="*70)
print("A4: Generate Test Data and Classify with kNN (k=3)")
print("="*70)

# Load training data from A3
try:
    X_train = np.load('X_train.npy')
    y_train = np.load('y_train.npy')
    print(f"✓ Loaded training data: {X_train.shape[0]} points")
except FileNotFoundError:
    print("ERROR: Training data not found!")
    print("Please run A3_training_data.py first to generate training data.")
    exit()

# Generate test set with X & Y varying from 0 to 10 with increments of 0.1
print("\nGenerating test data...")
x_range = np.arange(0, 10.1, 0.1)
y_range = np.arange(0, 10.1, 0.1)
xx, yy = np.meshgrid(x_range, y_range)

# Create test set (about 10,000 points)
X_test = np.c_[xx.ravel(), yy.ravel()]

print(f"Test Data Shape: {X_test.shape}")
print(f"Total test points: {X_test.shape[0]}")

# Train kNN classifier with k=3
k = 3
print(f"\nTraining kNN classifier with k={k}...")
knn = KNeighborsClassifier(n_neighbors=k)
knn.fit(X_train, y_train)

# Predict test data
print("Classifying test points...")
y_test_pred = knn.predict(X_test)

print(f"✓ Classification completed for {len(y_test_pred)} test points")

# Calculate prediction distribution
print(f"\nPredicted class distribution:")
print(f"Class 0 (Blue): {np.sum(y_test_pred == 0)} points ({np.sum(y_test_pred == 0)/len(y_test_pred)*100:.1f}%)")
print(f"Class 1 (Red): {np.sum(y_test_pred == 1)} points ({np.sum(y_test_pred == 1)/len(y_test_pred)*100:.1f}%)")

# Plot test data with predicted colors
print("\nGenerating visualization...")
plt.figure(figsize=(12, 10))

# Plot test points colored by prediction
colors = ['blue', 'red']
class_names = ['Class 0 (Blue)', 'Class 1 (Red)']
cmap_light = ListedColormap(['lightblue', 'lightcoral'])

plt.scatter(X_test[:, 0], X_test[:, 1], c=y_test_pred, 
           cmap=cmap_light, s=10, alpha=0.5, edgecolors='none',
           label='Test predictions')

# Overlay training points (larger, with black edges)
for class_idx in range(2):
    mask = y_train == class_idx
    plt.scatter(X_train[mask, 0], X_train[mask, 1], 
               c=colors[class_idx], label=f'Training {class_names[class_idx]}',
               s=200, edgecolors='black', linewidths=2, marker='o', alpha=0.9, zorder=5)

plt.xlabel('Feature X', fontsize=12)
plt.ylabel('Feature Y', fontsize=12)
plt.title(f'A4: Test Data Classification with kNN (k={k})\nDecision Boundary Visualization', 
         fontsize=14, fontweight='bold')
plt.legend(fontsize=11, loc='upper right')
plt.grid(True, alpha=0.3)
plt.xlim(-0.5, 10.5)
plt.ylim(-0.5, 10.5)
plt.tight_layout()
plt.savefig('A4_knn_k3_classification.png', dpi=300)
plt.show()

print(f"✓ Test data classification plot (k={k}) saved as 'A4_knn_k3_classification.png'")

print("\n" + "="*70)
print("OBSERVATIONS:")
print("="*70)
print("- Test set contains 10,201 points (101 x 101 grid)")
print("- kNN classifier with k=3 creates decision boundaries")
print("- Light blue regions: areas predicted as Class 0")
print("- Light red/coral regions: areas predicted as Class 1")
print("- Decision boundaries are visible where colors transition")
print("- Training points (with black borders) show the original data")
print("- The classifier assigns test points based on majority vote of 3 nearest neighbors")
print("="*70)