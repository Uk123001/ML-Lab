import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report, precision_score, recall_score, f1_score
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.utils import to_categorical
import os
from PIL import Image

# Set random seeds for reproducibility
np.random.seed(42)
import tensorflow as tf
tf.random.set_seed(42)

# Configuration
IMG_SIZE = 128
BATCH_SIZE = 4
EPOCHS = 50
CLASS_NAMES = ['elliptical', 'spiral', 'irregular']
NUM_CLASSES = len(CLASS_NAMES)

# Function to load images from folders
def load_data(data_dir):
    images = []
    labels = []
    
    for class_idx, class_name in enumerate(CLASS_NAMES):
        class_path = os.path.join(data_dir, class_name)
        if not os.path.exists(class_path):
            print(f"Warning: {class_path} does not exist!")
            continue
            
        for img_name in os.listdir(class_path):
            if img_name.lower().endswith(('.png', '.jpg', '.jpeg')):
                img_path = os.path.join(class_path, img_name)
                try:
                    img = Image.open(img_path).convert('RGB')
                    img = img.resize((IMG_SIZE, IMG_SIZE))
                    img_array = np.array(img) / 255.0
                    images.append(img_array)
                    labels.append(class_idx)
                except Exception as e:
                    print(f"Error loading {img_path}: {e}")
    
    return np.array(images), np.array(labels)

# Load data (adjust the path to your dataset folder)
DATA_DIR = 'galaxy_dataset'  # Change this to your dataset path
X, y = load_data(DATA_DIR)

print(f"Loaded {len(X)} images")
print(f"Image shape: {X[0].shape}")
print(f"Class distribution: {np.bincount(y)}")

# Split data into training and test sets (70-30 split)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

print(f"\nTraining samples: {len(X_train)}")
print(f"Test samples: {len(X_test)}")

# Convert labels to categorical
y_train_cat = to_categorical(y_train, NUM_CLASSES)
y_test_cat = to_categorical(y_test, NUM_CLASSES)

# Data augmentation for training
train_datagen = ImageDataGenerator(
    rotation_range=20,
    width_shift_range=0.2,
    height_shift_range=0.2,
    horizontal_flip=True,
    zoom_range=0.2
)

# Build CNN model
model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(IMG_SIZE, IMG_SIZE, 3)),
    MaxPooling2D(2, 2),
    
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    
    Flatten(),
    Dense(128, activation='relu'),
    Dropout(0.5),
    Dense(NUM_CLASSES, activation='softmax')
])

model.compile(
    optimizer='adam',
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

model.summary()

# Train the model
history = model.fit(
    train_datagen.flow(X_train, y_train_cat, batch_size=BATCH_SIZE),
    epochs=EPOCHS,
    validation_data=(X_test, y_test_cat),
    verbose=1
)

# Predictions
y_train_pred = np.argmax(model.predict(X_train), axis=1)
y_test_pred = np.argmax(model.predict(X_test), axis=1)

# Function to calculate and display metrics
def evaluate_model(y_true, y_pred, dataset_name):
    print(f"\n{'='*60}")
    print(f"{dataset_name} Performance Metrics")
    print(f"{'='*60}")
    
    # Confusion Matrix
    cm = confusion_matrix(y_true, y_pred)
    
    # Calculate metrics
    precision = precision_score(y_true, y_pred, average=None, zero_division=0)
    recall = recall_score(y_true, y_pred, average=None, zero_division=0)
    f1 = f1_score(y_true, y_pred, average=None, zero_division=0)
    
    # Overall metrics
    precision_avg = precision_score(y_true, y_pred, average='weighted', zero_division=0)
    recall_avg = recall_score(y_true, y_pred, average='weighted', zero_division=0)
    f1_avg = f1_score(y_true, y_pred, average='weighted', zero_division=0)
    
    # Display confusion matrix
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=CLASS_NAMES, yticklabels=CLASS_NAMES)
    plt.title(f'Confusion Matrix - {dataset_name}')
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.tight_layout()
    plt.savefig(f'confusion_matrix_{dataset_name.lower().replace(" ", "_")}.png', dpi=300)
    plt.show()
    
    # Print detailed metrics
    print("\nConfusion Matrix:")
    print(cm)
    
    print("\nPer-Class Metrics:")
    print(f"{'Class':<15} {'Precision':<12} {'Recall':<12} {'F1-Score':<12}")
    print("-" * 60)
    for i, class_name in enumerate(CLASS_NAMES):
        print(f"{class_name:<15} {precision[i]:<12.4f} {recall[i]:<12.4f} {f1[i]:<12.4f}")
    
    print("\nOverall Metrics (Weighted Average):")
    print(f"Precision: {precision_avg:.4f}")
    print(f"Recall:    {recall_avg:.4f}")
    print(f"F1-Score:  {f1_avg:.4f}")
    
    print("\nClassification Report:")
    print(classification_report(y_true, y_pred, target_names=CLASS_NAMES, zero_division=0))
    
    return cm, precision, recall, f1

# Evaluate on training data
cm_train, prec_train, rec_train, f1_train = evaluate_model(y_train, y_train_pred, "Training Data")

# Evaluate on test data
cm_test, prec_test, rec_test, f1_test = evaluate_model(y_test, y_test_pred, "Test Data")

# Plot training history
plt.figure(figsize=(12, 4))

plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Model Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Model Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.savefig('training_history.png', dpi=300)
plt.show()

# Learning Outcome Analysis
print("\n" + "="*60)
print("LEARNING OUTCOME ANALYSIS")
print("="*60)

train_acc = history.history['accuracy'][-1]
val_acc = history.history['val_accuracy'][-1]
train_loss = history.history['loss'][-1]
val_loss = history.history['val_loss'][-1]

print(f"\nFinal Training Accuracy:   {train_acc:.4f}")
print(f"Final Validation Accuracy: {val_acc:.4f}")
print(f"Final Training Loss:       {train_loss:.4f}")
print(f"Final Validation Loss:     {val_loss:.4f}")

# Determine model fitting status
print("\n--- Model Fitting Assessment ---")

if train_acc > 0.95 and val_acc < 0.7:
    outcome = "OVERFIT"
    print(f"Status: {outcome}")
    print("Explanation: High training accuracy but significantly lower validation accuracy.")
    print("The model has memorized the training data but doesn't generalize well.")
    print("Recommendations: Add more data, increase dropout, reduce model complexity, or add regularization.")
    
elif train_acc < 0.7 and val_acc < 0.7:
    outcome = "UNDERFIT"
    print(f"Status: {outcome}")
    print("Explanation: Both training and validation accuracies are low.")
    print("The model hasn't learned the patterns in the data effectively.")
    print("Recommendations: Increase model complexity, train longer, or improve data quality.")
    
elif abs(train_acc - val_acc) < 0.1 and train_acc > 0.7:
    outcome = "REGULARFIT (Good Fit)"
    print(f"Status: {outcome}")
    print("Explanation: Training and validation accuracies are close and reasonably high.")
    print("The model generalizes well to unseen data.")
    print("This is the desired outcome!")
    
elif train_loss < val_loss and (val_loss - train_loss) > 0.3:
    outcome = "OVERFIT (based on loss)"
    print(f"Status: {outcome}")
    print("Explanation: Validation loss is significantly higher than training loss.")
    print("Recommendations: Add regularization or more training data.")
    
else:
    outcome = "MODERATE FIT"
    print(f"Status: {outcome}")
    print("Explanation: The model shows reasonable performance with room for improvement.")
    print("Recommendations: Fine-tune hyperparameters or collect more data.")

print(f"\n{'='*60}")
print(f"FINAL OUTCOME: {outcome}")
print(f"{'='*60}\n")

# Save the model
model.save('galaxy_classifier_model.h5')
print("Model saved as 'galaxy_classifier_model.h5'")


