import numpy as np
import matplotlib.pyplot as plt

# Set random seed for reproducibility
np.random.seed(42)

print("="*70)
print("A3: Generate Training Data and Scatter Plot")
print("="*70)

# Generate 20 training data points with 2 features (X, Y) between 1 and 10
n_train_points = 20
X_train = np.random.uniform(1, 10, size=(n_train_points, 2))

# Assign to 2 classes (0 - Blue, 1 - Red) randomly
y_train = np.random.randint(0, 2, size=n_train_points)

print(f"\nTraining Data Shape: {X_train.shape}")
print(f"Training Labels Shape: {y_train.shape}")
print(f"\nFirst 5 training samples:")
print(f"{'X':<8} {'Y':<8} {'Class':<8}")
print("-"*25)
for i in range(5):
    print(f"{X_train[i, 0]:<8.2f} {X_train[i, 1]:<8.2f} {y_train[i]:<8}")

print(f"\nClass distribution:")
print(f"Class 0 (Blue): {np.sum(y_train == 0)} points")
print(f"Class 1 (Red): {np.sum(y_train == 1)} points")

# Plot training data
plt.figure(figsize=(10, 8))
colors = ['blue', 'red']
class_names = ['Class 0 (Blue)', 'Class 1 (Red)']

for class_idx in range(2):
    mask = y_train == class_idx
    plt.scatter(X_train[mask, 0], X_train[mask, 1], 
               c=colors[class_idx], label=class_names[class_idx],
               s=100, edgecolors='black', linewidths=1.5, alpha=0.7)

plt.xlabel('Feature X', fontsize=12)
plt.ylabel('Feature Y', fontsize=12)
plt.title('A3: Training Data Scatter Plot (20 points)', fontsize=14, fontweight='bold')
plt.legend(fontsize=11)
plt.grid(True, alpha=0.3)
plt.xlim(0, 11)
plt.ylim(0, 11)
plt.tight_layout()
plt.savefig('A3_training_data.png', dpi=300)
#plt.show()

print("\n✓ Training data scatter plot saved as 'A3_training_data.png'")

# Save training data for use in A4 and A5
np.save('X_train.npy', X_train)
np.save('y_train.npy', y_train)
print("✓ Training data saved as 'X_train.npy' and 'y_train.npy'")

print("\n" + "="*70)
print("OBSERVATIONS:")
print("="*70)
print("- Generated 20 random training points with features X and Y between 1-10")
print("- Points are randomly assigned to Class 0 (Blue) or Class 1 (Red)")
print("- Scatter plot shows the spatial distribution of both classes")
print("- The random distribution creates a classification problem for kNN")
print("="*70)