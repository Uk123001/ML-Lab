import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree

# Load dataset
df = pd.read_csv("galaxy_features.csv")
X = df.drop("label", axis=1).values
y = df["label"].values
feature_names = df.drop("label", axis=1).columns.tolist()
print(f"Loaded: {X.shape[0]} samples, {X.shape[1]} features, {len(set(y))} classes")

# A1 - Entropy
def entropy(y):
    counts = Counter(y)
    total = len(y)
    h = 0
    for count in counts.values():
        p = count / total
        if p > 0:
            h -= p * np.log2(p)
    return h

print(f"\nA1 - Entropy: {entropy(y):.4f}")

# A2 - Gini Index
def gini(y):
    counts = Counter(y)
    total = len(y)
    return 1 - sum((count / total) ** 2 for count in counts.values())

print(f"A2 - Gini Index: {gini(y):.4f}")

# A4 - Binning (defined before A3 since A3 uses it)
def bin_feature(x, n_bins=4, method="equal_width"):
    if method == "equal_width":
        bins = np.linspace(x.min(), x.max(), n_bins + 1)
    elif method == "equal_frequency":
        quantiles = np.linspace(0, 100, n_bins + 1)
        bins = np.unique(np.percentile(x, quantiles))
    else:
        raise ValueError("method must be 'equal_width' or 'equal_frequency'")
    return np.digitize(x, bins[:-1]) - 1

print(f"\nA4 - Binning on feature '{feature_names[0]}':")
sample = X[:, 0]
print(f"  Equal width (first 10):     {bin_feature(sample)[:10]}")
print(f"  Equal frequency (first 10): {bin_feature(sample, n_bins=4, method='equal_frequency')[:10]}")

# A3 - Find best root node using Information Gain
def information_gain(X, y, feature_idx, n_bins=4, method="equal_width"):
    x = X[:, feature_idx].astype(float)
    x_binned = bin_feature(x, n_bins=n_bins, method=method)
    parent_H = entropy(y)
    total = len(y)
    weighted_H = sum(
        (len(y[x_binned == b]) / total) * entropy(y[x_binned == b])
        for b in np.unique(x_binned)
    )
    return parent_H - weighted_H

def find_root_node(X, y, feature_names):
    gains = [information_gain(X, y, i) for i in range(X.shape[1])]
    best_idx = np.argmax(gains)
    print("\nA3 - Information Gain per feature:")
    for name, g in zip(feature_names, gains):
        print(f"  {name:20s}: {g:.4f}")
    print(f"\n  Best root node: '{feature_names[best_idx]}' (IG = {gains[best_idx]:.4f})")
    return best_idx, gains

root_idx, all_gains = find_root_node(X, y, feature_names)

# A5 - Decision Tree Implementation
class DecisionNode:
    def __init__(self, feature_idx=None, threshold=None,
                 left=None, right=None, value=None):
        self.feature_idx = feature_idx
        self.threshold = threshold
        self.left = left
        self.right = right
        self.value = value

class MyDecisionTree:
    def __init__(self, max_depth=5, min_samples=5):
        self.max_depth = max_depth
        self.min_samples = min_samples
        self.root = None

    def fit(self, X, y):
        self.root = self._build(X, y, depth=0)

    def _build(self, X, y, depth):
        if depth >= self.max_depth or len(y) < self.min_samples or len(set(y)) == 1:
            return DecisionNode(value=Counter(y).most_common(1)[0][0])

        best_feat, best_thresh, best_ig = None, None, -1
        for feat_idx in range(X.shape[1]):
            for thresh in np.unique(X[:, feat_idx]):
                left_mask = X[:, feat_idx] <= thresh
                right_mask = ~left_mask
                if left_mask.sum() == 0 or right_mask.sum() == 0:
                    continue
                ig = entropy(y) - (
                    (left_mask.sum() / len(y)) * entropy(y[left_mask]) +
                    (right_mask.sum() / len(y)) * entropy(y[right_mask])
                )
                if ig > best_ig:
                    best_ig = ig
                    best_feat = feat_idx
                    best_thresh = thresh

        if best_feat is None:
            return DecisionNode(value=Counter(y).most_common(1)[0][0])

        left_mask = X[:, best_feat] <= best_thresh
        left  = self._build(X[left_mask],  y[left_mask],  depth + 1)
        right = self._build(X[~left_mask], y[~left_mask], depth + 1)
        return DecisionNode(feature_idx=best_feat, threshold=best_thresh,
                            left=left, right=right)

    def _predict_one(self, x, node):
        if node.value is not None:
            return node.value
        if x[node.feature_idx] <= node.threshold:
            return self._predict_one(x, node.left)
        return self._predict_one(x, node.right)

    def predict(self, X):
        return np.array([self._predict_one(x, self.root) for x in X])

    def score(self, X, y):
        return np.mean(self.predict(X) == y)

print("\nA5 - Training decision tree...")
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
my_dt = MyDecisionTree(max_depth=5)
my_dt.fit(X_train, y_train)
print(f"A5 - My Decision Tree Accuracy: {my_dt.score(X_test, y_test)*100:.2f}%")

# A6 - Visualizing decision tree
print("\nA6 - Visualizing decision tree...")
sk_dt = DecisionTreeClassifier(max_depth=4, criterion="entropy")
sk_dt.fit(X_train, y_train)
print(f"A6 - Sklearn Decision Tree Accuracy: {sk_dt.score(X_test, y_test)*100:.2f}%")

plt.figure(figsize=(26, 8))
plot_tree(sk_dt, feature_names=feature_names,
          class_names=[str(i) for i in range(10)],
          filled=True, fontsize=7, max_depth=3)
plt.title("Decision Tree - Galaxy10 Dataset", fontsize=14)
plt.tight_layout()
plt.savefig("decision_tree.png", dpi=150)
plt.show()

# A7 - Decision Boundary using top 2 features by Information Gain
top2 = np.argsort(all_gains)[-2:]
f1, f2 = top2[0], top2[1]
print(f"\nA7 - Decision Boundary using '{feature_names[f1]}' and '{feature_names[f2]}'")

X2 = X[:, [f1, f2]]
X2_train, X2_test, y2_train, y2_test = train_test_split(X2, y, test_size=0.2, random_state=42)

dt2 = DecisionTreeClassifier(max_depth=4, criterion="entropy")
dt2.fit(X2_train, y2_train)

x_min, x_max = X2[:, 0].min() - 0.5, X2[:, 0].max() + 0.5
y_min, y_max = X2[:, 1].min() - 0.5, X2[:, 1].max() + 0.5
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 300),
                     np.linspace(y_min, y_max, 300))
Z = dt2.predict(np.c_[xx.ravel(), yy.ravel()]).reshape(xx.shape)

plt.figure(figsize=(10, 7))
plt.contourf(xx, yy, Z, alpha=0.3, cmap="tab10")
scatter = plt.scatter(X2[:, 0], X2[:, 1], c=y, cmap="tab10", edgecolors="k", s=20)
plt.colorbar(scatter, label="Galaxy Class")
plt.xlabel(feature_names[f1])
plt.ylabel(feature_names[f2])
plt.title("Decision Boundary - Galaxy10 (Top 2 Features)")
plt.tight_layout()
plt.savefig("decision_boundary.png", dpi=150)
plt.show()
print("Done. Saved decision_tree.png and decision_boundary.png")